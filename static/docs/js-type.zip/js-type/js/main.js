"use strict";

/**
 * (問題 1)
 * BMIを計算して、console.log()で表示しよう。
 * 計算方法: BMI = 体重 / (身長 * 身長)
 */
const weight = 60;
const height = 170;

/**
 * (問題 2)
 * 好きな食べ物の配列を作成してconsole.log()で表示しよう。
 * ex) const myFavoridFood = ["ラーメン","カレー"]
 */

/**
 * (問題 3)
 * myProfileのメンバーに自己紹介を記入しよう
 * ex) name, age, gender, favoriteFood など。
 */

const myProfile = {};

/* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 * 以下は触らなくてOK
 */

//myProfileをページに表示する処理
function showProfile() {
    const myProfileKeys = Object.keys(myProfile);
    if (myProfileKeys.length === 0) {
        return;
    }
    document.write(`<h1>プロフィール</h1>`);
    for (let index = 0; index < myProfileKeys.length; index++) {
        const key = myProfileKeys[index];
        document.write(`<h2>[${key}] ${myProfile[key]}</h2>`);
    }
}
// DOMContentLoadedに `showProfile()`
document.addEventListener(
    "DOMContentLoaded",
    function() {
        showProfile();
    },
    false
);
