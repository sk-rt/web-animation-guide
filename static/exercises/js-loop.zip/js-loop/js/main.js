"use strict";

/**
 * (問題 1) for
 * 配列`myFavoridFoods` の中身をfor文を使って全てconsoleに出力しよう。
 */
const myFavoridFoods = ["ラーメン", "カレー", "寿司", "ハンバーグ"];

/**
 * (問題 1) for / if
 * 2の問題を修正して "カレー"の時は絵文字: 🍛 を`alert`で表示しよう。
 */

/**
 * (問題 2) function / for
 * 任意の数 `n` を引数にして、0からnまで画面に出力する関数 `counter`を完成させて実行しよう。
 * 画面への出力は `document.write()` を使うこと。例: `document.write(index);`
 */
function counter(n){
    // ここに処理書く
}
// counterを実行
counter(100);

/**
 * (問題 3) function / for / if
 * 3の問題を修正して, 99以上の数は表示されない様に変更しよう
 * ループを抜けるには `break;` 文を使用すること。
 */
