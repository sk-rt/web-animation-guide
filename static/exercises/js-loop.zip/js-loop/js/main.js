"use strict";

/**
 * (問題 1) for
 * 配列`myFavoridFoods` の中身をfor分を使って全てconsoleに出力しよう。
 */
const myFavoridFoods = ["ラーメン", "カレー", "寿司", "ハンバーグ"];

/**
 * (問題 1) for
 * 2の問題を修正して "カレー"の時は絵文字: 🍛 を表示しよう。
 */

/**
 * (問題 2) 関数 / for
 * 任意の数 `n` を引数にして、その数だけ console に出力する関数を定義しよう。
 * 関数名 `counter`
 */

/**
 * (問題 3) 関数 / for / if
 * 3の問題を修正して, `3の倍数`の時だけ出力する関数にしよう
 * 関数名 `counterOnThree`
 * 3の倍数かどうかは ` number % 3 === 0 ` で判定
 */

/**
 * (問題 4) 番外編
 * 無限 alert()
 * for文で無限にアラートを出そう。
 *
 * ⚠️無闇に書き込むと逮捕されます。 https://nlab.itmedia.co.jp/nl/articles/1903/11/news095.html
 */
