"use strict";

/**
 * (例)
 * 文字列 `name` の前に `Hello`を足して返す関数。
 */
function greeting(name) {
    return "Hello," + name + "さん";
}
console.log(greeting("田中")); // Hello,田中さん

/**
 * (問題 1)
 * 数値 `a` と `b` を 乗算(掛け算)して返す関数を定義しよう。
 * 関数名 `multiplied`
 */

/**
 * (問題 2)
 *  `document.write()` を使って
 * HTMLに 引数 `message` を表示させる関数を定義しよう
 */
