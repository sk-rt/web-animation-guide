"use strict";

/*
(問題 1)
1. class名が`button-bark` のボタン要素を取得して、変数`btnBark`に代入しよう。
2. `alert("わん！")` を実行する関数 `bark`を定義しよう。
3. 1で取得したボタン`btnBark` が `click` された時、２で定義した関数 `bark`を実行するイベントを登録しよう。
 */



/*
(問題 2)
1. class名が`button-spin` の要素を取得して変数`btnSpin`に代入しよう。
2. class名が`my-dog`の要素を取得して、変数`myDog`に代入しよう。
3. `myDog` にclass `is-spinning`を追加する関数 `spin`を定義しよう。
 */

/*
(問題 3)
class名が`button-sitdown` の要素をクリックすると、 `myDog` の class `is-spinning` を削除する処理を書いてみよう。
 */

