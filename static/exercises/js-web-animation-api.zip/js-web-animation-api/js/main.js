"use strict";

/*
(問題 1) 文字のアニメーション

 `element.animate()` メソッドを使って `.title-row-1` 〜　`title-row-3` をアニメーションさせてみよう。
 アニメーションは `ex1-text-animation.mp4`を参考。


 ※実行後の状態を維持するため、
 アニメーションオプションに `fill: "both"`
 を設定すること。

*/

/*
(問題 2) 装飾のアニメーション

 `.ornament` をアニメーションさせてみよう。
  アニメーションは `ex1-ornament-animation.mp4`を参考。

*/
