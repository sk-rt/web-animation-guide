"use strict";


/**
 * (問題 1) 変数宣言
 * const を使って変数 `myName` を宣言して自分の名前を代入しよう。
 */


/**
 * (問題 2) querySelector()
 * 1. document.querySelector()を使って `.my-name`を取得し、変数 `myNameElement`に代入しよう。
 * 2. また、console.log()とconsole.dir()で`myNameElement`を出力して確認しよう。
 */


/**
 * (問題 3) 要素の操作
 * 1. `element.innerHTML` で(問題 2)で取得した要素の中身を(問題 1)で宣言した変数 `myName`に書き換えよう。
 * 2. また、`element.classList.add()` で class `big-title`を追加しよう。
 */


/**
 * (問題 4) Styleの変更
 * `.block` 要素を取得して、element.styleを使って背景色を変更しよう。
 */
